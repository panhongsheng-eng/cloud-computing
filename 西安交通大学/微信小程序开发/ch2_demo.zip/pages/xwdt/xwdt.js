// pages/xwdt/xwdt.js
Page({
  data: {
    array: []
  },
  onLoad: function (options) {
    var array = this.initData();
    this.setData({ array: array });
  },
  initData: function () {
    var array = [];
    var object1 = new Object();
    object1.img = '../images/list1.png';
    object1.title = '2019年西安交通大学—香港理工大学丝路暑期《可持续发展》课程项目圆满结束';
    object1.type = '教改项目';
    object1.liulan = '1234浏览';
    object1.pinglun = '4评论';
    array[0] = object1;

    var object2 = new Object();
    object2.img = '../images/list2.png';
    object2.title = '2019年国家精品在线开放课程申报工作启动会顺利召开';
    object2.type = '课程建设';
    object2.liulan = '298浏览';
    object2.pinglun = '3评论';
    array[1] = object2;

    var object3 = new Object();
    object3.img = '../images/list3.png';
    object3.title = '教务处成功举办思源教学沙龙专题工作坊';
    object3.type = '教学沙龙';
    object3.liulan = '185浏览';
    object3.pinglun = '2评论';
    array[2] = object3;
    return array;
  }
})